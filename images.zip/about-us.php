<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"  "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
        <title>Single Page</title>
        <link href="styles.css" rel="stylesheet" type="text/css">
        <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet" type="text/css">
    </head>
    <body style="margin:2em;">
    <div id="home" class="top-image">
        <header>
            <div class="main-body">
                <nav>
                    <a href="index.php">
                        <img class="pull-left logo" src="images/logo.png" alt="Logo">
                    </a>
                    <ul class="">                        
                        <li><a class="active" href="index.php">Home </a></li>
                        <li><a href="about-us.php" >About Us </a></li>
                        <li><a href="contact-us.php" >Contact Us </a></li>
                    </ul>
                </nav>
            </div>
            <div class="spotlight">
                <h1>We Strive for excellence</h1>
            </div>
        </header>
    </div>
    <section>
        <div id="content" class="site-content">
            <div class="container-fluid"style="padding:0;">
                <div class="col-lg-12" style="padding:0;">
                    <div class=" pull-left col-md-7" style="padding:0 50px;">
                        <div class="pull-left">
                            <hr class="pull-right hr-red">
                            <div class="clearfix"></div>
                            <span class="top-talent">Top Talents </br> Academy</span>
                        </div>
                        <div class="clearfix"></div>
                        <div class="pull-left">
                            <p class="pull-left paragraph">
                                Lorem Ipsum is simply dummy text of the printing and typesetting industry.
                                Lorem Ipsum has been the industry's standard dummy text ever since the 1500.
                                Lorem Ipsum is simply dummy text of the printing and typesetting industry.
                                Lorem Ipsum has been the industry's standard dummy text ever since the 1500.
                            </p>
                        </div>
                    </div>

                    <div class="pull-right col-md-offset-1 col-md-4" style="padding:0;">
                        <div class="insurance-subscribe">
                            <div class="quote">
                                <div class="past-results">
                                    <span>Download Past  <br>  KCPE Results</span>
                                </div>
                                <span><img style=" width:50%; margin: 2em 7.5em;" src="images/book.png" alt="Logo"></span>
                                <input type="submit" name="vehicle" value="Past Results">
                            </div>
                        </div>
                    </div>
                    <div class="clearfix"></div>
                </div>
            </div>
        </div>
    </section>


    <section id="photos">
            <img src="images/bus1.png" alt="Logo">
            <img src="images/bus2.png" alt="Logo">
            <img src="images/classrooms.png" alt="Logo">
            <img src="images/attention.png" alt="Logo">
            <img src="images/children_parade.png" alt="Logo">
            <img src="images/girls_singing.png" alt="Logo">
            <img src="images/playing_soccer.png" alt="Logo">
    </section>

    <footer>
        <div class="home-footer">
            <div class="page-wrapper" style="margin: 0 10%">
                <div class="col-lg-12">
                    <div class="footercontent">
                        <div class="copyright pull-left">
                        <!--    &copy;  &#169;  &#xA9;  &#9400;    -->                            
                        <span>&#9400; 2016. All Rights Reserved. Designed by Tatu Creatives ltd and Developed by David Ndekere</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </footer>
</body>
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-material-design/4.0.2/bootstrap-material-design.iife.js" type="text/javascript"></script>
</html>